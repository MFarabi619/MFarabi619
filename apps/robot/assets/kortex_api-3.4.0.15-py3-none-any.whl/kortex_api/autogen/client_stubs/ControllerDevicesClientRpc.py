
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import ControllerDevices_pb2 as ControllerDevicesPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class ControllerDevicesFunctionUid(Enum):
    uidGetStorageList = 0x320001
    uidGetFileSystemList = 0x320002
    uidGetLocalUpdateFileList = 0x320003
    uidFileWrite = 0x320004
    uidFileRead = 0x320005
    uidOnNotificationStorageTopic = 0x320006
    uidUnsubscribe = 0x320007
    uidGetConnectedDevicesList = 0x320008



class ControllerDevicesClient():
    
    serviceVersion = 1
    serviceId = 50

    

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a ControllerDevicesClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def Unsubscribe(self, notificationhandle: CommonPb.NotificationHandle, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Unsubscribes client from receiving notifications for the specified topic
        """
        reqPayload = notificationhandle.SerializeToString()

        if not isinstance(self.router._transport, MqttTransport):
            future = self.router._send(reqPayload, self.serviceVersion, ControllerDevicesFunctionUid.uidUnsubscribe, deviceId, self.namespace, options)

            result = future.result(options.getTimeoutInSecond())



        self.router._unregisterNotificationCallback(notificationhandle.identifier, self.namespace)

